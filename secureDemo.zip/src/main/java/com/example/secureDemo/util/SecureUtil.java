package com.example.secureDemo.util;


import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Hex;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

public class SecureUtil {
	private static String defaultSecretKey = "timeIsYours";

	/**
	 *
	 * 인코딩
	 *
	 * @param message 인코딩 대상,secretKey 암호화키
	 * @return String 인코딩값
	 */
	public static String encrypt(String message, String secretKey) {

		if (ObjectUtils.isEmpty(secretKey)) {
			return message;
		}

		if (!StringUtils.hasText(message)) {
			return message;
		}

		String base64EncryptedString = null;
		try {
			byte[] bytes = secretKey.getBytes();
			SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
			sr.setSeed(bytes);
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			kgen.init(128, sr);

			SecretKey skey = kgen.generateKey();
			SecretKeySpec skeySpec = new SecretKeySpec(skey.getEncoded(), "AES");
			Cipher c = Cipher.getInstance("AES");
			c.init(Cipher.ENCRYPT_MODE, skeySpec);

			byte[] encrypted = c.doFinal(message.getBytes("UTF-8"));
			base64EncryptedString = Hex.encodeHexString(encrypted);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return base64EncryptedString;
	}

	/**
	 *
	 * 인코딩
	 *
	 * @param message 인코딩 대상
	 * @return String 인코딩값
	 */
	public static String encrypt(String message) {
		return encrypt(message, defaultSecretKey);
	}

	/**
	 *
	 * 디코딩
	 *
	 * @param encryptedText 대코딩 대상,secretKey 암호화키
	 * @return String 디코딩값
	 */
	public static String decrypt(String encryptedText, String secretKey) {

		if (ObjectUtils.isEmpty(secretKey)) {
			return encryptedText;
		}

		if (!StringUtils.hasText(encryptedText)) {
			return encryptedText;
		}

		String decryptedText = null;
		try {
			byte[] bytes = secretKey.getBytes();
			SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
			sr.setSeed(bytes);
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			kgen.init(128, sr);

			SecretKey skey = kgen.generateKey();
			SecretKeySpec skeySpec = new SecretKeySpec(skey.getEncoded(), "AES");

			Cipher c = Cipher.getInstance("AES");
			c.init(Cipher.DECRYPT_MODE, skeySpec);
			byte[] decrypted = c.doFinal(Hex.decodeHex(encryptedText.toCharArray()));
			decryptedText = new String(decrypted, "UTF-8");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return decryptedText;
	}

	/**
	 *
	 * 디코딩
	 *
	 * @param encryptedText 대코딩 대상
	 * @return String 디코딩값
	 */
	public static String decrypt(String encryptedText) {

		return decrypt(encryptedText, defaultSecretKey);
	}
}
