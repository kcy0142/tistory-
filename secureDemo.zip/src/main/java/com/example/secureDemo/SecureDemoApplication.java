package com.example.secureDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecureDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecureDemoApplication.class, args);
	}

}
