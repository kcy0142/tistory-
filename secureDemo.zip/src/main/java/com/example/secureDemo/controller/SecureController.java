package com.example.secureDemo.controller;


import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.secureDemo.util.SecureUtil;


@RestController
@RequestMapping("/secure")
public final class SecureController {

	// http://localhost:8080/secure/retrieveEncryptInfo

	

	// 암호화 데이터 수신
	@RequestMapping(value = "/retrieveEncryptInfo", method = RequestMethod.POST)
	public ResponseEntity<String> retrieveEncryptInfo(
			@RequestHeader(name = "secure-client-token", required = true) String token,
			@RequestHeader(name = "X-COM-LOCATION", defaultValue = "ASIA") String headerLocation,
			@RequestBody Map<String, Object> params) {

		String result = "ok";
		System.out.println("#####token:" + token);
		System.out.println("#####chatId:" + params.get("chatId"));
		

		String decryptMessage = SecureUtil.decrypt(token);

		String[] decryptParam = decryptMessage.split(",");
		System.out.println("#####decryptMessage:" + decryptMessage);

		String message = decryptParam[0];
		String time = decryptParam[1];
		System.out.println("#####decryptMessage message:" + message);
		System.out.println("#####decryptMessage time:" + time);
		long sendTime = 12345678910L;
		try {
			sendTime = Long.parseLong(time);
			System.out.println("long l = " + sendTime);
		} catch (NumberFormatException nfe) {
			System.out.println("NumberFormatException: " + nfe.getMessage());
		}

		long gapTime = System.currentTimeMillis() - sendTime;
		System.out.println("gapTime = " + gapTime + ",second:" + gapTime / 1000);

		//1분안에 값만 유효데이터로 처리
		if(( gapTime / 1000)>60) {
			//비정상 데이터로 간주
			result = "no";
			System.out.println("#######chatId = " + params.get("chatId")+" 에서 비 정상 데이터  유입");
		}else {
			//정상 데이터로 간주
			System.out.println("chatId = " + params.get("chatId")+" 에서 데이터 정상 유입");
		}
		return ResponseEntity.ok(result);

	}

}
