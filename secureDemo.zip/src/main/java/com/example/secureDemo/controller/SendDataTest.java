package com.example.secureDemo.controller;


import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.example.secureDemo.util.SecureUtil;

import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;

public class SendDataTest {



	public static void main(String[] args) {

		String secureToken = "nh/IlRmgOhVnyhguUBi8aw==";
		Long currentTime=1656141221472L;
		Long currentTime1 = System.currentTimeMillis();
		String encryptMessage = secureToken + "," + currentTime;
		String secureClientToken = SecureUtil.encrypt(encryptMessage);
		String secureClientDecrypt = SecureUtil.decrypt(secureClientToken);

		System.out.println("currentTime:" + currentTime);
		System.out.println("secureClientToken:" + secureClientToken);
		System.out.println("secureClientDecrypt:" + secureClientDecrypt);

		RestTemplate restTemplate = new RestTemplate();

		String url = "http://localhost:8080/secure/retrieveEncryptInfo";
		String requestJson = "{\"chatId\":\"120000080013\",\"targetUserId\":\"00305\",\"message\":\"myMessage:i love you^^\",\"action\":\"test\",\"title\":\"i wanna go with you\"}";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("secure-client-token", secureClientToken);

		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
		String answer = restTemplate.postForObject(url, entity, String.class);

		System.out.println(answer);

		String sTime = "100";

		try {
			long l = Long.parseLong(sTime);
			System.out.println("long l = " + l);
		} catch (NumberFormatException nfe) {
			System.out.println("NumberFormatException: " + nfe.getMessage());
		}

		String nowTime2 = "1547171550767";
		long millis2 = System.currentTimeMillis();
		System.out.println(" nowTime == " + millis2);

		long aa = System.currentTimeMillis() - currentTime;
		System.out.println(System.currentTimeMillis() - currentTime);

	}

}